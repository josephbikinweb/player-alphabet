-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2021 at 11:46 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `videoplayer`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `categories` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categories`) VALUES
(1, 'war'),
(2, 'romance'),
(3, 'action'),
(4, 'biography'),
(5, 'comedy'),
(6, 'detective'),
(7, 'drama'),
(8, 'fantasy'),
(9, 'history'),
(10, 'horror'),
(11, 'kungfu'),
(12, 'mystery'),
(13, 'sci-fi'),
(14, 'thriller'),
(16, 'korea');

-- --------------------------------------------------------

--
-- Table structure for table `extension`
--

CREATE TABLE `extension` (
  `id` int(11) NOT NULL,
  `ext` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `extension`
--

INSERT INTO `extension` (`id`, `ext`) VALUES
(1, 'mp4'),
(2, 'mkv');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `type` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `type`) VALUES
(3, 'movies'),
(4, 'tvshows');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `folder` varchar(255) NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `extension_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `nama_gambar` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `folder`, `nama_file`, `extension_id`, `categories_id`, `type_id`, `nama_gambar`) VALUES
(2, 'harry potter', 'Harry Potter and the Goblet of Fire (2005)', 2, 2, 3, 'Harry Potter and the Goblet of Fire (2005)'),
(3, 'harry potter', 'Harry Potter and the Order of the Phoenix (2007)', 2, 2, 4, 'Harry Potter and the Order of the Phoenix (2007)'),
(6, 'avenger', 'Avengers- Endgame', 2, 1, 3, 'avenger endgame'),
(7, 'avenger', 'Avengers- Infinity War', 2, 1, 3, 'avenger infinity war'),
(8, 'ironman', 'Iron Man (2008)', 2, 1, 4, 'ironman'),
(9, 'ironman', 'Iron Man 2', 2, 1, 4, 'ironman2'),
(10, 'ironman', 'Iron Man 3', 2, 1, 4, 'iroman3'),
(18, 'captain america', 'Captain America- The First Avenger', 2, 1, 3, 'Captain-America-1'),
(22, 'captain america', 'America- Civil War', 2, 1, 3, 'Captain-America-2'),
(23, 'dog', 'THE CALL OF THE WILD Trailer (2020) Harrison Ford Dog Movie', 1, 1, 3, 'the-call-of-the-wild');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `extension`
--
ALTER TABLE `extension`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_id` (`categories_id`),
  ADD KEY `type_id` (`type_id`),
  ADD KEY `extension_id` (`extension_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `extension`
--
ALTER TABLE `extension`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `video`
--
ALTER TABLE `video`
  ADD CONSTRAINT `video_ibfk_1` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `video_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`),
  ADD CONSTRAINT `video_ibfk_3` FOREIGN KEY (`extension_id`) REFERENCES `extension` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
