<?php  
 require 'function.php';
 $id = $_GET["id"];
 $char = '';  
 if(isset($_GET["char"]))  
 {  
      $char = $_GET["char"];  
      $char = preg_replace('#[^a-z]#i', '', $char);  
      $catVideos = query("SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id WHERE v.categories_id = $id AND v.nama_file LIKE '$char%'");

 }  
 else  
 {  
      $catVideos = query("SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id WHERE v.categories_id = $id");

 }  
 
 ?>  
<!DOCTYPE html>
    <html lang="en" >
    <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="//stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css" />
    <title>Creatrix</title>
    
    <style>
      body {
        background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("images/background2.jpg");
        background-color: #fafafa;
        background-repeat: no-repeat;
        background-position: center center;
        background-size: cover;
      }
    </style>
</head>
<body>
  <nav class="navbar transp navbar-expand-md navbar-dark">
    <div class="hidden-sm-down">
      <span class="navbar-brand link" data-href="index.php">
        <span class="fa fa-video-camera fa-fw text-info"></i></span>Creatrix</span>
    </div>
  </nav>

 <div class="container alpha-container mt-3">
    <div class="row">
       
        <?php  
            $character = range('A', 'Z');  
        ?>
        <ul class="pagination">  
            <li><a href="cat.php?id=<?= $id ?>&char=''">#</a></li>
        <?php   
            foreach($character as $alphabet)  
            {  
              echo '<li><a href="cat.php?id='.$id.'&char='.$alphabet.'">'.$alphabet.'</a></li>';  
            }  
        ?>  
        </ul>  
      
     </div>
  </div>

  <div class="container">
    <table class="table table-borderless" id="myTable">
        <thead class="thead-dark">
          <tr>
            <th scope="col">No.</th>
            <!--Aksi untuk tombol ubah  -->
            <th scope="col">Judul</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <?php $i = 1; ?>
            <?php foreach ($catVideos as $video) : ?>

                <th class="th-row"><?= $i; ?> </th>
                <td>
                  <a class="th-row" href="player.php?id=<?= $video["id"]; ?>"><?= $video["nama_file"]; ?></a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach ?>
        </tbody>
    </table>
  </div>
  
  

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
  <script src="//stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
  <script src="js/script.js"></script>
  <script>
      $(document).ready( function () {
      $('#myTable').DataTable();
    } );
  </script>
  </body>
</html>
