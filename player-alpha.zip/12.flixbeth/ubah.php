<?php  
require "function.php";

$id = $_GET["id"];

$videos = query("SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id");

$tabelVideo = query ("SELECT * FROM video WHERE id = $id")[0];

$extensions = query ("SELECT * FROM extension");

$categories = query('SELECT * FROM categories');

$types = query ("SELECT * FROM type");
// cek apakah tombol submit sudah ditekan atau belum
    if (isset ($_POST["submit"])) {

// untuk fungsi debug / cek codingannya bekerja atau tidak :
// die supaya coding dibawahnya tidak dijalankan
        // var_dump($_POST); 
        // var_dump($_FILES); die;

// cek apakah data berhasil ditambahkan atau tidak
        if (ubah($_POST) > 0){
            // echo "Data berhasil ditambahkan";
            echo "
                <script>
                    alert ('data berhasil diubah');
                    document.location.href = 'tambah.php';
                </script>
            ";
        } else {
            // echo"Data GAGAL ditambahkan";
            echo "<script>
                    alert ('data gagal diubah');
                    document.location.href = 'tambah.php';
                </script>
                ";
        }
    }
    
    if (isset($_POST["cari"])) {
    $video = cari($_POST["keyword"]);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <html lang="en" >
    <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="//stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/main.css" />
    <title>Creatrix Tambah Video</title>
</head>
<body>
  
    <div class="container">
        
            <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $tabelVideo["id"];?>" >

            <h1 class="mt-3">Ubah Data Video</h1>
                <div class="form-group">
                    <label for="folder">Folder :</label>
                    <input type="text" name="folder" id="folder" class="form-control" value="<?= $tabelVideo["folder"];?>">
                </div>
                
                <div class="form-group">
                    <label for="nama_file">Nama File :</label>
                    <input type="text" name="nama_file" id="nama_file" class="form-control" value="<?= $tabelVideo["nama_file"];?>">
                </div>

                <div class="form-group">
                    <label for="extension_id">Extension :</label>
                    <select name="extension_id" id="extension_id" class="form-control" value="<?= $tabelVideo["extension_id"];?>" selected>
                      <?php  foreach ( $extensions as $extension ) :?>
                      <option value="<?=  $extension['id'] ?>"><?=  $extension['ext'] ?></option>
                      <?php  endforeach ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="categories_id">Categories :</label>
                    <select name="categories_id" id="categories_id" class="form-control" value="<?= $tabelVideo["categories_id"];?>" selected>
                      <?php  foreach ( $categories as $category ) :?>
                      <option value="<?=  $category['id'] ?>"><?=  $category['categories'] ?></option>
                      <?php  endforeach ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="type_id">Jenis :</label>
                    <select name="type_id" id="type_id" class="form-control" value="<?= $tabelVideo["type_id"];?>" selected>
                      <?php  foreach ( $types as $type ) :?>
                      <option value="<?=  $type['id'] ?>"><?=  $type['type'] ?></option>
                      <?php  endforeach ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="nama_gambar">Nama Gambar :</label>
                    <input type="text" name="nama_gambar" id="nama_gambar" class="form-control" value="<?= $tabelVideo["nama_gambar"];?>">
                </div>
                
                  <button type="submit" name="submit" class="btn btn-primary">Ubah Data Video</button>
               </form>
        
    </div>

    <div class="container my-5">
    <div class="row">
      <form action="" method="post" class="mx-2">
        <div class="form-inline">
          <input type="text" name="keyword" size="40" autofocus placeholder="masukkan keyword pencarian.." autocomplete="off"  class="form-control" id="keyword">
          <button type="submit" name="cari" class="btn btn-primary ml-2" id="tombol-cari">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
              <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
            </svg>
          </button>
        </div>
      </form>
    </div>
  </div>

   <div class="container" id="container">
    <div class="row">
      <table class="table table-borderless">
        <thead class="thead-dark">
          <tr>
            <th scope="col">No.</th>
            <!--Aksi untuk tombol ubah  -->
            <th scope="col">Judul</th>
            <th scope="col">Categories</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <?php $i = 1; ?>
            <?php foreach ($videos as $video) : ?>

                <th scope="row"><?= $i; ?> </th>
                <td>
                  <a href="player.php?id=<?= $video["id"]; ?>"><?= $video["nama_file"]; ?></a>
                </td>
                <td>
                  <a href="categories.php?id=<?= $video["categories_id"]; ?>"><?= $video["categories"]; ?></a>
                </td>
                <td>
                  <a href="ubah.php?id=<?= $video["id"];?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-fill" viewBox="0 0 16 16">
                    <path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708l-3-3zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.5-.5V10h-.5a.499.499 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>
                    </svg>
                  </a> |
                  <a href="hapus.php?id=<?= $video["id"];?>" 
                      onclick="return confirm('Yakin?');">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
                    <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
                    </svg>
                  </a>
                </td>
            </tr>
            <?php $i++; ?>
            <?php endforeach ?>
        </tbody>
      </table>
    </div>
  </div>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
  <script src="//stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
  <script src="js/script.js"></script>
</body>
</html>