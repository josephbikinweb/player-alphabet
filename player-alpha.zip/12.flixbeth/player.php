<?php

require 'function.php';
$id = $_GET["id"];

$play = query("SELECT v.id, v.folder, v.nama_file, v.extension_id,e.ext, v.categories_id, c.categories, v.type_id, t.type, v.nama_gambar FROM video AS v INNER JOIN categories AS c ON v.categories_id = c.id INNER JOIN extension AS e ON v.extension_id = e.id INNER JOIN type AS t ON v.type_id = t.id WHERE v.id = $id")[0];

$categories = query('SELECT * FROM categories');

$types = query('SELECT * FROM type');

?>
<!DOCTYPE html>
    <html lang="en" ><head><meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="stylesheet" href="//stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css" /><link rel="stylesheet" href="/assets/css/tooltipster.bundle.min.css" />
    <title>Creatrix</title>
    
    <style>
      body {
        background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)),
        url("images/background2.jpg");
        background-color: #fafafa;
        background-repeat: no-repeat;
        background-position: center center;
        background-size: cover;
      }
    </style>
</head>
<body>
  <nav class="navbar transp navbar-expand-md navbar-dark">
    <div class="hidden-sm-down">
      <span class="navbar-brand link" data-href="index.php">
        <span class="fa fa-video-camera fa-fw text-info"></i></span>Creatrix</span>
    </div>
  </nav>
  
  <div class="container">
    <div class="row">
        <video class="video" controls>
          <source src="movies/<?= $play["folder"]; ?>/<?= $play["nama_file"]; ?>.<?= $play["ext"]; ?>" type="video/mp4">
        </video>
      </div>
  </div>
  </body>
</html>
