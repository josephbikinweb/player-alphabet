<?php
require 'function.php';

    $id = $_GET["id"];

    if (hapusCategories($id) > 0){
        echo"
                <script>
                    alert ('data berhasil dihapus');
                    document.location.href = 'tambahCategories.php';
                </script>
        ";
    } else {
        // echo"
        //         <script>
        //             alert ('data gagal dihapus');
        //             document.location.href = 'tambahCategories.php';
        //         </script>
        // ";
    }

?>